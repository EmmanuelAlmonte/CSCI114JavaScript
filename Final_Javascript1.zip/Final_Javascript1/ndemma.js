'use strict'


$(function() {
    let contentClick = '';
    let productImg = $('.imgsDiv');
    
    productImg.addClass
    

    $('.carsContent').on('click',function(evnt){
        let carClick = evnt.originalEvent.isTrusted;
        if(carClick=true){
            contentClick= 'car';
            
        }
        productClicked(contentClick);
 

    });
    
    
        
    
    $('.bikesContent').on('click', function(evnt){
        let bikeClick = evnt.originalEvent.isTrusted;
        if(bikeClick= true){
            contentClick= 'bike';
            
        }
        else if(contentClick!='bike'){
            console.log('not equal');
        }
        productClicked(contentClick);
        


    });

 
    

    $('.ballsContent').on('click', function(evnt){
        let ballClick = evnt.originalEvent.isTrusted;
        if(ballClick= true){
            contentClick= 'ball';
            
        }
        else if(contentClick!='toy'){
            console.log('not equal');
        }
        productClicked(contentClick);
        

    });

    $('.toysContent').on('click', function(evnt){
        let toyClick = evnt.originalEvent.isTrusted;
        if(toyClick= true){
            contentClick= 'toy';
            
        }
        else if(contentClick!='toy'){
            console.log('not equal');
        }
        productClicked(contentClick);
        
    });



    function productClicked(product){
        if(product =='car'){
            productImg.removeClass('hideImg');
            let firstImg = $('#firstImg').attr('src', 'imgs/cars/car1.jpeg');
            let secondImg = $('#secondImg').attr('src', 'imgs/cars/car2.jpeg');
            let thirdImg = $('#thirdImg').attr('src', 'imgs/cars/car3.jpeg');
            let fourthImg = $('#fourthImg').attr('src', 'imgs/cars/car4.jpeg');
            let fifthImg = $('#fifthImg').attr('src', 'imgs/cars/car5.jpeg');
            let sixthImg = $('#sixthImg').attr('src', 'imgs/cars/car6.jpeg');
        }
        else if(product =='bike'){
            productImg.removeClass('hideImg');
            let firstImg = $('#firstImg').attr('src', 'imgs/bikes/blackbike.jpeg');
            let secondImg = $('#secondImg').attr('src', 'imgs/bikes/bluedritbike.jpeg');
            let thirdImg = $('#thirdImg').attr('src', 'imgs/bikes/dirtbikeload.jpeg'); 
            let fourthImg = $('#fourthImg').attr('src', 'imgs/bikes/motorbike.jpeg');
            let fifthImg = $('#fifthImg').attr('src', 'imgs/bikes/tanbike.jpeg');
            let sixthImg = $('#sixthImg').attr('src', 'imgs/bikes/bike6.jpg');
        }
        else if(product== 'ball'){
            productImg.removeClass('hideImg');
            let firstImg = $('#firstImg').attr('src','imgs/balls/baseball.jpeg ');
            let secondImg = $('#secondImg').attr('src', 'imgs/balls/soccer.jpeg');
            let thirdImg = $('#thirdImg').attr('src', 'imgs/balls/softball.jpeg'); 
            let fourthImg = $('#fourthImg').attr('src', 'imgs/balls/football.jpeg');
            let fifthImg = $('#fifthImg').attr('src', 'imgs/balls/tennis.jpeg');
            let sixthImg = $('#sixthImg').attr('src', 'imgs/balls/bball.jpg');
        }
        else if(product== 'toy'){
            productImg.removeClass('hideImg');
            let firstImg = $('#firstImg').attr('src', 'imgs/Toys/helicopter.jpeg');
            let secondImg = $('#secondImg').attr('src', 'imgs/Toys/nerfgun1(1).jpeg');
            let thirdImg = $('#thirdImg').attr('src', 'imgs/Toys/nerfpistol.jpeg'); 
            let fourthImg = $('#fourthImg').attr('src', 'imgs/Toys/plane.jpeg');
            let fifthImg = $('#fifthImg').attr('src', 'imgs/Toys/watergun.jpeg');
            let sixthImg = $('#sixthImg').attr('src', 'imgs/Toys/waterpistol.jpeg');
        }

        else{
            console.log('else');
        }
    };


});