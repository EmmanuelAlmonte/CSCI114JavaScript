'use strict';


$(function() {



    let userChoice = $('#user-info');
    userChoice.removeClass('clicked');

    let x = true

    //let unorderList = $('<li>');
    
    //let firstImg = productImg[0].children[0].children[0];
    
    //let firstImg = $('#firstImg').attr('src', 'imgs/cars/car1.jpeg');
   

    $('#button').on('click', function(evnt) {
        let userName = $('#full-name').val();
        evnt.preventDefault();

        console.log('Form submitted!', userName);
    });

    //Decides what user selects between guest and create an account. 
    $("input[type='radio']").click( function(){
        let choice = $("input[type=radio][name='account-type']:checked").val();
        if( choice == 'user'){
            userChoice.addClass('clicked');
        }
        else{
            userChoice.removeClass('clicked');
        }
    });

    //submits the user information for the account.
   




    /*
    $.ajax({
      method: "PUT",
      url: "userdatam.json",
      data: { name: "John", location: "Boston" }
    })
      .done(function( ) {
        console.log('dataSaved');
      });
             console.log(carClick);
        contentClick= 'car';
        if(contentClick=='car'){
            console.log(contentClick);
            console.log('cars');

        }

    
              if(contentClick='bike'){
            let firstImg = $('#firstImg').attr({'src': 'imgs/bikes/blackbike.jpeg', 'alt':'gat'});
            let secondImg = $('#secondImg').attr({'src': '', 'alt':'gat'});
            let thirdImg = $('#thirdImg').attr({'src': '', 'alt':'gat'});
            productImg.removeClass('hideImg');
      */


});